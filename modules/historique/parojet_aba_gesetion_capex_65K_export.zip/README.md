# parojet aba gesetion capex 65K

## Description


## Informations du Projet
- **Créé le**: 26/06/2025 à 14:03
- **Version de sauvegarde**: 2.0
- **Score de complétude**: 100.0%
- **Taille des données**: 0.0 MB

## Modules Actifs
data_import, configuration, economic_analysis, optimization, monte_carlo

## Contenu du Projet

### Données Disponibles
- Configuration: ✅
- Scénarios: ✅
- Données de production: ❌
- Données de consommation: ❌
- Résultats économiques: ❌
- Résultats d'optimisation: ❌
- Résultats Monte Carlo: ❌

### Visualisations Sauvegardées
0 graphiques et tableaux sauvegardés

## Validation des Données
- **Statut**: ✅ Valide
- **Score de qualité**: 100%

### Avertissements


## Structure des Fichiers
```
parojet aba gesetion capex 65K/
├── manifest.json              # Métadonnées du projet
├── session_state_complete.json # Capture exhaustive de l'état
├── config.json                 # Configuration
├── scenarios.json              # Scénarios définis
├── production_data.csv         # Données de production
├── consumption_data.csv        # Données de consommation
├── economic_results.json       # Résultats économiques
├── optimization_results.json   # Résultats d'optimisation
├── monte_carlo_results.json    # Résultats Monte Carlo
├── charts/                     # Graphiques sauvegardés
└── tables/                     # Tableaux Excel
```

## Comment Utiliser ce Projet
1. Ouvrez OptimPV
2. Allez dans l'onglet "Sauvegarde et Historique"
3. Cliquez sur "Charger le projet sélectionné"
4. Sélectionnez ce projet dans la liste

---
*Généré automatiquement par OptimPV v2.0*
